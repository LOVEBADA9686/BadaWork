package a.b.c.kosmo.login.service;

import a.b.c.kosmo.mem.vo.HbeMemberVO;

public interface HbeLoginService {

	public int hLoginCheck(HbeMemberVO hvo);
}
