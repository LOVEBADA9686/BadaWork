package a.b.c.kosmo.login.dao;

import a.b.c.kosmo.mem.vo.HbeMemberVO;

public interface HbeLoginDAO {

	public int hLoginCheck(HbeMemberVO hvo);
}
